# Your own Claude in the Barnyard chat

The **Claude** page on the Barnyard hub (`dashboard.barnyard.site/chat.html`) can talk to **your own Claude**, running on **your own computer** with **your own Claude subscription**. This folder is the small program that makes that work. Nothing about your Claude account is ever sent to Barnyard: the page only passes your messages to the program and shows what it writes back.

```
the chat page (signed in as you) ──► Barnyard Worker ──► your messages wait in your own room
                                              ▲
                                              │ asks "anything for me?" once a minute (outgoing only)
                        this program, on your computer ◄── runs Claude Code with your account,
                                              │             reading one folder you chose
                                              └─► posts the reply back
```

It only ever makes **outgoing** connections. It opens no port, and nothing on the internet can reach your computer.

## What Claude can and cannot do

- It can **read** the one folder you share (and look at its git history if it is a repository), and answer general questions.
- It **cannot change anything**: the folder is mounted read-only, and edit tools, pushing, the web and other programs are switched off.
- It cannot see the rest of your computer, your passwords, or your Claude login (the login is only used by Claude Code inside the container).
- Other Barnyard users cannot see your conversations, and you cannot see theirs. The owner of the hub can switch guest chats off for everyone.

## What you need

- A computer that can run **Docker** (Docker Desktop on Windows or Mac).
- A **Claude subscription** (Pro or Max) and Claude Code, only to run one command once (below).
- The chat to be open to you (if the page says it is not available, ask the owner).

## Set-up (about ten minutes)

1. **Make a runner key.** On the chat page, choose **Connect your Claude**, give the key a name (for example "Home laptop") and press **Make key**. The key starts with `cr_` and is shown **once**. Copy it.
2. **Unzip this folder** somewhere you will keep it, and open a terminal in it.
3. **Save the key.** Create the folder `secrets` and, inside it, a file called `chat_runner_key.txt` containing only the key (no quotes, no extra words, one line).
4. **Get your Claude login token.** Install Claude Code if you have not (`npm install -g @anthropic-ai/claude-code`), then run `claude setup-token`. It signs you in in your browser and prints a long token (valid for a year). Save it as `secrets/claude_oauth_token.txt`, the same way. Treat both files like passwords.
5. **Choose what Claude may read.** Put the folder in `shared` (create it, or copy files into it), or point `SHARED_DIR` at an existing folder: for example on Mac or Linux `SHARED_DIR=/Users/me/Notes docker compose up -d --build`, on Windows PowerShell `$env:SHARED_DIR="C:\Users\me\Notes"; docker compose up -d --build`. Claude sees only that folder, read-only.
6. **Start it:**
   ```
   docker compose up -d --build
   docker compose logs -f runner
   ```
   You should see `runner starting; Claude Code 2.1.x`. Within about a minute the chat page changes from "your Claude is not connected" to **connected**, and you can start a conversation.

Any trouble: the logs name the problem in plain words (for example "the runner key has expired: make a new one on the chat page").

## Everyday use

- Your computer must be on, and Docker running, for your Claude to answer. If it is off the page says so.
- **Stop it:** `docker compose down`. **Start again:** `docker compose up -d`.
- The chat allows a few messages a minute and 60 a day for each person, and only a few people at a time can connect a runner.
- Each message uses a little of your own Claude allowance, the same pool as the Claude app.

## Revoking and rotating

- **Stop everything now:** on the chat page, revoke the key (it stops working at once), and `docker compose down`.
- **Keys expire** after 30, 90 or 365 days (you choose when you make one). When yours does, make a new key, replace `secrets/chat_runner_key.txt`, and run `docker compose restart runner`.
- **The Claude login token** lasts a year. Sign out of the session at claude.ai to revoke it.

## Checking the download

The hub publishes the checksum of this file (SHA-256) on the chat page next to the download. Compare it with `Get-FileHash guest-runner.zip` (PowerShell) or `shasum -a 256 guest-runner.zip` (Mac/Linux) before you unzip.

## What is not covered (said plainly)

- This program runs on your computer, so you are trusting it with the folder you share (read-only) and your Claude login token. Read it if you like: it is a few small JavaScript files in `src/`.
- Text in your files could try to steer Claude (prompt injection). Share only a folder you are happy for Claude to read, and treat what it says about files you did not write with care.
- Using a subscription from a program is the headless route Anthropic documents (`claude setup-token`), kept personal here: your account, your computer, your own conversations. Check Anthropic's current terms for your plan.
