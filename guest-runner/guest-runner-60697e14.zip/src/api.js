// The runner's only conversation with the Worker: ask for the next job, post events about it.
// Every call is an outgoing HTTPS request with the runner's own bearer token; nothing here
// listens on a port. Errors never include the token or the response body.

export class ApiError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

export function createApi({ base, token, fetchImpl = fetch, timeoutMs = 20000 }) {
  async function call(method, path, body) {
    let res;
    try {
      res = await fetchImpl(base + path, {
        method,
        headers: { Authorization: `Bearer ${token}`, ...(body ? { "Content-Type": "application/json" } : {}) },
        body: body ? JSON.stringify(body) : undefined,
        redirect: "manual",
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch (e) {
      throw new ApiError("could not reach the Worker", 0);
    }
    if (res.status === 401) {
      // The one answer worth reading: an expired key says so (the Worker only says this to someone who holds the secret).
      let expired = false;
      try { const j = await res.json(); expired = !!j && j.error === "key_expired"; } catch (e) { /* not JSON */ }
      throw new ApiError(expired ? "the runner key has expired: make a new one on the chat page" : "the Worker refused the runner token (CHAT_RUNNER_TOKEN)", 401);
    }
    if (res.status === 503) throw new ApiError("the chat is switched off or not ready (CHAT_ENABLED / CHAT_RUNNER_TOKEN on the Worker)", 503);
    if (res.status === 429) throw new ApiError("the Worker is rate limiting the runner", 429);
    if (!res.ok) throw new ApiError(`the Worker answered ${res.status}`, res.status);
    try { return await res.json(); } catch (e) { throw new ApiError("the Worker's answer was not JSON", res.status); }
  }
  return {
    // -> {job: {id, conv, text, mode, sessionId} | null, pollMs}
    next: () => call("GET", "/chat/runner/next"),
    // -> {ok, stop}
    events: (job, events) => call("POST", "/chat/runner/events", { job, events }),
  };
}
