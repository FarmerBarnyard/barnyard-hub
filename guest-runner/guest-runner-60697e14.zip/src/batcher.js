// Collects events and sends them to the Worker in batches: at most one request per
// interval, consecutive text joined into one piece, and no more than the Worker accepts in
// one request (60 events, 8,000 characters of text each). Requests never overlap, so events
// arrive in order. A failed send keeps the events and tries again on the next tick.

const MAX_EVENTS = 60;
const MAX_TEXT = 8000;

export function createBatcher({ send, intervalMs, onStop, onFailure, setTimer = setTimeout, clearTimer = clearTimeout }) {
  let queue = [];
  let timer = null;
  let sending = null;
  let failures = 0;
  let closed = false;

  function push(e) {
    const last = queue[queue.length - 1];
    if (e.kind === "delta" && last && last.kind === "delta" && last.text.length + e.text.length <= MAX_TEXT) {
      last.text += e.text;
      return;
    }
    if (e.kind === "delta" && e.text.length > MAX_TEXT) {
      for (let i = 0; i < e.text.length; i += MAX_TEXT) queue.push({ kind: "delta", text: e.text.slice(i, i + MAX_TEXT) });
      return;
    }
    queue.push(e.kind === "delta" ? { ...e } : e);
  }

  function schedule() {
    if (timer || closed) return;
    timer = setTimer(() => { timer = null; flush(); }, intervalMs);
  }

  // Send what is queued. Resolves when the queue is empty or a send failed.
  async function flush() {
    if (sending) return sending;
    sending = (async () => {
      try {
        while (queue.length) {
          const batch = queue.slice(0, MAX_EVENTS);
          let res;
          try { res = await send(batch); } catch (err) {
            failures++;
            if (onFailure) onFailure(failures);
            schedule();
            return false;
          }
          failures = 0;
          queue = queue.slice(batch.length);
          if (res && res.stop && onStop) onStop();
        }
        return true;
      } finally { sending = null; }
    })();
    return sending;
  }

  return {
    add(e) {
      if (closed) return;
      push(e);
      // The end of a job goes out at once; everything else waits for the next tick.
      if (e.kind === "done" || e.kind === "error") { if (timer) { clearTimer(timer); timer = null; } flush(); } else schedule();
    },
    // Send everything that is left (used when the process has ended). Retries a few times.
    async close(retries = 3, wait = (ms) => new Promise((r) => setTimeout(r, ms))) {
      if (timer) { clearTimer(timer); timer = null; }
      for (let i = 0; i <= retries; i++) {
        if (sending) await sending;
        if (!queue.length) break;
        if (await flush()) break;
        await wait(Math.min(2000 * (i + 1), 8000));
      }
      closed = true;
      return !queue.length;
    },
    get pending() { return queue.length; },
    get failures() { return failures; },
  };
}
