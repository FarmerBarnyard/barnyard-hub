// Runner configuration, read once from the environment. Secrets may come from a file
// (CHAT_RUNNER_TOKEN_FILE, CLAUDE_CODE_OAUTH_TOKEN_FILE: Docker secrets) so they never sit in
// a process listing or a compose file. Nothing here is ever printed.

import fs from "node:fs";

const REPO_NAME = /^[A-Za-z0-9._-]{1,100}$/;
// A guest's runner key (made on the chat page): cr_<32 hex>_<43 base64url>.
const GUEST_KEY = /^cr_[0-9a-f]{32}_[A-Za-z0-9_-]{43}$/;
export const DEFAULT_REPOS = ["ClaudeRepo", "barnyard-hub", "study-hub", "campaign-hub", "market-dashboard"];

function secret(env, name) {
  const file = env[`${name}_FILE`];
  if (file) {
    try { return fs.readFileSync(file, "utf8").trim(); } catch (e) { throw new Error(`${name}_FILE could not be read`); }
  }
  return typeof env[name] === "string" ? env[name].trim() : "";
}

function int(env, name, def, min, max) {
  if (env[name] === undefined || env[name] === "") return def;
  const n = Number(env[name]);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be a whole number from ${min} to ${max}`);
  return n;
}

export function loadConfig(env = process.env) {
  const api = (env.CHAT_API_URL || "https://api.barnyard.site").replace(/\/+$/, "");
  // The runner's token goes in an Authorization header on every poll: never over plain http
  // (a local test server is the one exception).
  if (!/^https:\/\//.test(api) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(api)) throw new Error("CHAT_API_URL must start with https://");
  // "owner": the original runner (the owner's server, the five repositories, edit mode). "guest": a guest's own
  // runner on their own computer: read-only, no repositories to clone, and it reads one folder they chose.
  const profile = env.RUNNER_PROFILE === undefined || env.RUNNER_PROFILE === "" ? "owner" : env.RUNNER_PROFILE;
  if (profile !== "owner" && profile !== "guest") throw new Error("RUNNER_PROFILE must be owner or guest");
  const runnerToken = secret(env, "CHAT_RUNNER_TOKEN");
  if (runnerToken.length < 20) throw new Error("CHAT_RUNNER_TOKEN is missing or too short");
  if (profile === "guest" && !GUEST_KEY.test(runnerToken)) throw new Error("CHAT_RUNNER_TOKEN must be the runner key made on the chat page (it starts with cr_)");
  const claudeToken = secret(env, "CLAUDE_CODE_OAUTH_TOKEN");
  if (!claudeToken) throw new Error("CLAUDE_CODE_OAUTH_TOKEN is missing (run `claude setup-token`)");

  const repos = profile === "guest" ? [] : (env.RUNNER_REPOS ? env.RUNNER_REPOS.split(",").map((s) => s.trim()).filter(Boolean) : DEFAULT_REPOS);
  if (profile === "owner" && (!repos.length || !repos.every((r) => REPO_NAME.test(r) && r !== "." && r !== ".."))) throw new Error("RUNNER_REPOS is not a list of repository names");
  const owner = env.RUNNER_GITHUB_OWNER || "FarmerBarnyard";
  if (!REPO_NAME.test(owner)) throw new Error("RUNNER_GITHUB_OWNER is not a valid name");

  return {
    api, runnerToken, claudeToken, repos, owner, profile,
    guestDir: env.RUNNER_GUEST_DIR || "/workspace/shared",   // guest profile: the one folder Claude may read
    reposDir: env.RUNNER_REPOS_DIR || "/workspace/repos",
    editDir: env.RUNNER_EDIT_DIR || "/workspace/edit",
    home: env.RUNNER_HOME || env.HOME || "/home/runner",
    claudeBin: env.RUNNER_CLAUDE_BIN || "claude",
    claudeArgsPrefix: [],                       // tests put a script path here
    extraEnv: {},                               // tests pass ELECTRON_RUN_AS_NODE here
    model: env.RUNNER_MODEL || "",
    systemPromptFile: env.RUNNER_SYSTEM_PROMPT_FILE || "",
    maxTurns: int(env, "RUNNER_MAX_TURNS", 40, 1, 200),
    maxBudgetUsd: env.RUNNER_MAX_BUDGET_USD ? Number(env.RUNNER_MAX_BUDGET_USD) : 0,
    jobTimeoutMs: int(env, "RUNNER_JOB_TIMEOUT_MS", 10 * 60 * 1000, 10 * 1000, 14 * 60 * 1000),
    batchMs: int(env, "RUNNER_BATCH_MS", 1000, 50, 10000),
    stopGraceMs: int(env, "RUNNER_STOP_GRACE_MS", 10000, 100, 60000),
    refreshEveryMs: int(env, "RUNNER_REFRESH_MS", 5 * 60 * 1000, 0, 24 * 3600 * 1000),
    closeWaitMs: 8000,                          // longest pause between tries to deliver the last events
    supportsNoPrompts: true,                   // set from `claude --version` at start-up
  };
}
