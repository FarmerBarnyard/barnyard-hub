// Runs ONE chat job: starts Claude Code for the message, streams what it says to the Worker,
// obeys Stop, enforces the time limit, and always ends the job (done or error) so the page
// never waits on a message that nobody is working on.

import { spawn as realSpawn } from "node:child_process";
import { buildArgs, childEnv } from "./policy.js";
import { createStreamParser } from "./stream.js";
import { createBatcher } from "./batcher.js";

const MAX_SEND_FAILURES = 20;     // about this many failed posts in a row means the Worker cannot be reached: give up on the job

export async function runJob({ job, cfg, api, workspace, spawn = realSpawn, log = () => {}, baseEnv = process.env }) {
  let cwd;
  try { cwd = await workspace.prepare(job); } catch (e) {
    await api.events(job.id, [{ kind: "error", text: "The runner could not prepare the working folder." }]).catch(() => {});
    return { ok: false, reason: "workspace" };
  }

  let stopping = false;
  let child = null;
  let killTimer = null;
  let timeoutTimer = null;
  let giveUp = false;
  let stoppedBy = "";

  const stopChild = (why) => {
    if (stopping) return;
    stopping = true;
    stoppedBy = why;
    if (child) {
      try { child.kill("SIGINT"); } catch (e) { /* already gone */ }
      killTimer = setTimeout(() => { try { child.kill("SIGKILL"); } catch (e) { /* already gone */ } }, cfg.stopGraceMs);
    }
  };

  const batcher = createBatcher({
    send: (events) => api.events(job.id, events),
    intervalMs: cfg.batchMs,
    onStop: () => stopChild("stop"),
    onFailure: (n) => { if (n >= MAX_SEND_FAILURES) { giveUp = true; stopChild("unreachable"); } },
  });
  const parser = createStreamParser((e) => batcher.add(e));

  let stderrTail = "";
  // A guest's chat is read-only whatever the Worker says: the runner enforces it too.
  const mode = cfg.profile === "guest" ? "read" : job.mode;
  const args = [...cfg.claudeArgsPrefix, ...buildArgs({ cfg, mode, prompt: job.text, sessionId: job.sessionId || "" })];

  const exit = await new Promise((resolve) => {
    try {
      child = spawn(cfg.claudeBin, args, { cwd, env: childEnv(cfg, baseEnv), stdio: ["pipe", "pipe", "pipe"] });
      child.stdin.on("error", () => {});                  // Claude may exit before it has read all of it
      child.stdin.end(job.text);
    } catch (e) { resolve({ code: null, signal: null, spawnError: true }); return; }
    child.stdout.on("data", (d) => parser.feed(d));
    child.stderr.on("data", (d) => { stderrTail = (stderrTail + d.toString("utf8")).slice(-400); });
    child.on("error", () => resolve({ code: null, signal: null, spawnError: true }));
    child.on("close", (code, signal) => resolve({ code, signal }));
    timeoutTimer = setTimeout(() => stopChild("timeout"), cfg.jobTimeoutMs);
  });
  clearTimeout(killTimer);
  clearTimeout(timeoutTimer);
  parser.end();

  // The one closing event.
  const final = parser.final;
  let closing;
  if (stoppedBy === "stop") closing = { kind: "error", text: "Stopped." };
  else if (stoppedBy === "timeout") closing = { kind: "error", text: "This took too long and was stopped." };
  else if (stoppedBy === "unreachable") closing = null;
  else if (exit.spawnError) closing = { kind: "error", text: "The runner could not start Claude Code." };
  else if (final && final.ok) closing = { kind: "done", cost: final.cost === null ? undefined : final.cost };
  else if (final) closing = { kind: "error", text: final.subtype === "error_max_turns" ? "Claude stopped after too many steps." : "Claude could not finish this message." };
  else closing = { kind: "error", text: authHint(stderrTail) || `Claude Code stopped unexpectedly${exit.code === null ? "" : ` (exit ${exit.code})`}.` };
  if (closing) {
    if (closing.cost === undefined) delete closing.cost;
    batcher.add(closing);
  }
  const sent = await batcher.close(3, (ms) => new Promise((r) => setTimeout(r, Math.min(ms, cfg.closeWaitMs))));
  if (!sent) log("some events could not be delivered");
  return { ok: !!(final && final.ok) && !stoppedBy, reason: stoppedBy || (final ? "finished" : "failed"), delivered: sent && !giveUp };
}

// A login problem is worth saying plainly; anything else stays generic (stderr can hold paths).
function authHint(tail) {
  return /not logged in|invalid (api key|token)|authentication|oauth|401/i.test(tail) ? "Claude Code is not signed in on the runner (check CLAUDE_CODE_OAUTH_TOKEN)." : "";
}
