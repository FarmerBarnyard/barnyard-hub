// What Claude may do, per mode, and the command line that says so.
//
// The runner never uses --dangerously-skip-permissions or --bare (--bare ignores the
// subscription login anyway). Each job starts with an explicit allow-list and
// --permission-mode dontAsk, so anything not listed is denied instead of asked about (nobody is
// there to answer). The same deny rules are also shipped as managed settings in the image
// (image/managed-settings.json), which a session cannot override: two places that must agree.
//
//   read  (default): look at the checked-out repositories and the Ops board. No file
//                    changes, no pushes, no web.
//   edit  (per conversation, owner's choice): also edit files in that conversation's own
//                    worktrees and push branches named claude/*. Never main.

export const READ_TOOLS = ["Read", "Grep", "Glob"];
// Claude starts in the folder that HOLDS the repositories, so to look at one it has to say which:
// `git -C campaign-hub log`. (`cd campaign-hub && git log` does not work: Claude Code refuses a cd followed
// by git, a known way to run a repository's own hooks.) Both forms are allowed here; the -C ones are what the
// system prompt teaches. -C may only name a folder below the current one (see DENY).
const READ_GIT = ["log", "diff", "show", "blame", "ls-files", "rev-parse"];
export const READ_BASH = [
  ...READ_GIT.map((c) => `Bash(git ${c} *)`),
  "Bash(git status)", "Bash(git status *)", "Bash(git branch --show-current)",
  ...READ_GIT.map((c) => `Bash(git -C * ${c} *)`),
  "Bash(git -C * status)", "Bash(git -C * status *)", "Bash(git -C * branch --show-current)",
  "Bash(ops-board *)",
];
export const EDIT_TOOLS = ["Edit", "Write"];
export const EDIT_BASH = [
  "Bash(git add *)", "Bash(git commit *)", "Bash(git restore *)",
  "Bash(git push origin claude/*)", "Bash(git push -u origin claude/*)", "Bash(git push --set-upstream origin claude/*)",
  "Bash(git checkout -b claude/*)", "Bash(git switch -c claude/*)",
  "Bash(git -C * add *)", "Bash(git -C * commit *)", "Bash(git -C * restore *)",
  "Bash(git -C * push origin claude/*)", "Bash(git -C * push -u origin claude/*)", "Bash(git -C * push --set-upstream origin claude/*)",
  "Bash(git -C * checkout -b claude/*)", "Bash(git -C * switch -c claude/*)",
];

// Denied in every mode. Deny wins over allow.
export const DENY = [
  "WebFetch", "WebSearch", "NotebookEdit",
  "Read(//proc/**)", "Read(//run/**)", "Read(//etc/**)", "Read(~/.claude/**)", "Read(**/.env)", "Read(**/.env.*)",
  "Edit(**/.claude/**)", "Write(**/.claude/**)", "Edit(**/.git/**)", "Write(**/.git/**)",
  "Bash(git push *main*)", "Bash(git push *master*)", "Bash(git push *--force*)", "Bash(git push *+*)", "Bash(git push --mirror*)",
  "Bash(git config *)", "Bash(git remote *)", "Bash(git * --output*)",
  // The same refusals when git is run as `git -C <folder> ...`, which the allow rules now permit.
  "Bash(git -C * push *main*)", "Bash(git -C * push *master*)", "Bash(git -C * push *--force*)", "Bash(git -C * push *+*)", "Bash(git -C * push --mirror*)",
  "Bash(git -C * config *)", "Bash(git -C * remote *)",
  // -C may only name a folder below the current one, and no option may change git's own configuration
  // (`-c core.fsmonitor=...` runs a command), where it looks for hooks, or which git program runs.
  "Bash(git -C /*)", "Bash(git -C ~*)", "Bash(git -C *..*)",
  "Bash(git -c *)", "Bash(git * -c *)", "Bash(git * --config-env*)", "Bash(git * --exec-path*)", "Bash(git * --git-dir*)", "Bash(git * --work-tree*)",
  "Bash(env)", "Bash(env *)", "Bash(printenv*)", "Bash(cat /proc/*)",
];

export function toolsFor(mode) {
  return mode === "edit" ? [...READ_TOOLS, ...EDIT_TOOLS, "Bash"] : [...READ_TOOLS, "Bash"];
}

export function allowFor(mode) {
  return mode === "edit"
    ? [...READ_TOOLS, ...EDIT_TOOLS, ...READ_BASH, ...EDIT_BASH]
    : [...READ_TOOLS, ...READ_BASH];
}

// The argument list for one job. The prompt is NOT in it: job.js writes it to Claude's standard
// input, so it never shows in a process listing, never needs shell quoting, and a message that
// starts with "-" cannot be read as an option.
export function buildArgs({ cfg, mode, prompt, sessionId }) {
  if (mode !== "read" && mode !== "edit") throw new Error("mode must be read or edit");
  if (typeof prompt !== "string" || !prompt) throw new Error("prompt is required");
  const args = [
    "-p",
    "--output-format", "stream-json", "--verbose", "--include-partial-messages",
    "--permission-mode", "dontAsk",
  ];
  if (cfg.supportsNoPrompts) args.push("--permission-prompts", "none");
  args.push("--tools", toolsFor(mode).join(","));
  args.push("--allowedTools", ...allowFor(mode));
  args.push("--disallowedTools", ...DENY);
  // No MCP servers, and no project-level settings or hooks from the repositories themselves.
  args.push("--strict-mcp-config", "--setting-sources", "user");
  args.push("--max-turns", String(cfg.maxTurns));
  if (cfg.maxBudgetUsd > 0) args.push("--max-budget-usd", String(cfg.maxBudgetUsd));
  if (cfg.model) args.push("--model", cfg.model);
  if (cfg.systemPromptFile) args.push("--append-system-prompt-file", cfg.systemPromptFile);
  if (sessionId) args.push("--resume", sessionId);
  return args;
}

// The environment Claude (and so every command it runs) gets: a short list, no GitHub token, no runner token.
export function childEnv(cfg, base = process.env) {
  const env = {
    PATH: base.PATH || "/usr/local/bin:/usr/bin:/bin",
    HOME: cfg.home,
    LANG: base.LANG || "C.UTF-8",
    CLAUDE_CODE_OAUTH_TOKEN: cfg.claudeToken,
    GIT_TERMINAL_PROMPT: "0",
    CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: "1",
    DISABLE_TELEMETRY: "1",
    ...cfg.extraEnv,
  };
  if (base.OPS_BOARD_TOKEN_FILE) env.OPS_BOARD_TOKEN_FILE = base.OPS_BOARD_TOKEN_FILE;
  if (base.OPS_BOARD_URL) env.OPS_BOARD_URL = base.OPS_BOARD_URL;
  return env;
}
