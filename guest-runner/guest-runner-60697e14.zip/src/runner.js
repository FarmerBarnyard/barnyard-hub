// The runner's main loop: ask the Worker for work, run it, ask again. It only ever
// makes outgoing requests. While nothing is happening it asks every `pollMs` (the Worker
// says how often: slow when the chat page is closed, fast while it is open); when the
// Worker cannot be reached it backs off, doubling up to a minute.

import { runJob } from "./job.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function createRunner({ cfg, api, workspace, spawn, log = () => {}, wait = sleep, runJobImpl = runJob }) {
  let stopping = false;
  let current = null;
  let delay = 2000;

  async function loop() {
    while (!stopping) {
      let res;
      try {
        res = await api.next();
        delay = 2000;
      } catch (err) {
        log(`${err.message}; trying again in ${Math.round(delay / 1000)} s`);
        await wait(delay);
        delay = Math.min(delay * 2, 60000);
        continue;
      }
      if (res && res.job) {
        log(`job ${res.job.id} (${res.job.mode})`);
        current = runJobImpl({ job: res.job, cfg, api, workspace, spawn, log });
        try { const r = await current; log(`job ${res.job.id} ${r.reason}`); } catch (e) { log("a job failed unexpectedly"); }
        current = null;
        continue;                                  // look for the next one straight away
      }
      const ms = res && Number.isFinite(res.pollMs) ? Math.min(Math.max(res.pollMs, 1000), 60000) : 20000;
      await wait(ms);
    }
  }

  return {
    run: loop,
    // Finish the job in hand (if any), then leave the loop.
    async stop() { stopping = true; if (current) await current; },
  };
}
