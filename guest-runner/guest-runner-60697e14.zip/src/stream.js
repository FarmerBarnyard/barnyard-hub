// Turns the lines `claude -p --output-format stream-json --verbose --include-partial-messages`
// prints into the few events the chat page understands:
//   {kind:"session", sessionId}   {kind:"delta", text}   {kind:"tool", text}
//   {kind:"done", cost}           {kind:"error", text}
// It reads whole lines only (a chunk may end mid-line), ignores anything it does not
// recognise (the format gains new message types over time), and never throws on bad input.

const SESSION_ID = /^[A-Za-z0-9_-]{8,80}$/;

const oneLine = (v, n) => String(v === undefined || v === null ? "" : v).replace(/\s+/g, " ").trim().slice(0, n);

// "Read src/index.js", "Bash git log -5", "Grep needle" -- what Claude is doing, in a few words.
export function summariseTool(name, input) {
  const n = oneLine(name, 40) || "Tool";
  const i = input && typeof input === "object" ? input : {};
  if (typeof i.file_path === "string") return `${n} ${oneLine(i.file_path, 160)}`;
  if (n === "Bash" && typeof i.command === "string") return `Bash ${oneLine(i.command, 160)}`;
  if (typeof i.pattern === "string") return `${n} ${oneLine(i.pattern, 160)}`;
  if (typeof i.path === "string") return `${n} ${oneLine(i.path, 160)}`;
  return n;
}

export function createStreamParser(onEvent) {
  let buf = "";
  let sessionId = "";
  let sawPartial = false;      // text arrived as deltas, so whole-message text blocks would repeat it
  let emittedText = false;
  let breakBefore = false;     // a new message started after text: start it on a new paragraph
  let final = null;            // the result line, once seen

  const emit = (e) => { try { onEvent(e); } catch (err) { /* a consumer's failure must not stop parsing */ } };
  const setSession = (id) => {
    if (typeof id === "string" && SESSION_ID.test(id) && id !== sessionId) { sessionId = id; emit({ kind: "session", sessionId: id }); }
  };
  const text = (t) => {
    if (typeof t !== "string" || !t) return;
    emit({ kind: "delta", text: breakBefore && emittedText ? "\n\n" + t : t });
    breakBefore = false;
    emittedText = true;
  };

  function line(raw) {
    const s = raw.trim();
    if (!s || s[0] !== "{") return;
    let m;
    try { m = JSON.parse(s); } catch (e) { return; }
    if (!m || typeof m !== "object") return;

    if (m.type === "system") {
      if (m.subtype === "init") setSession(m.session_id);
      else if (m.subtype === "permission_denied" && typeof m.tool_name === "string") emit({ kind: "tool", text: `Blocked: ${oneLine(m.tool_name, 60)}` });
      return;
    }
    // Messages from subagents carry the id of the call that started them; the page shows only the main thread.
    if (m.parent_tool_use_id) return;

    if (m.type === "stream_event" && m.event && typeof m.event === "object") {
      const ev = m.event;
      if (ev.type === "message_start") { if (emittedText) breakBefore = true; }
      else if (ev.type === "content_block_delta" && ev.delta && ev.delta.type === "text_delta") { sawPartial = true; text(ev.delta.text); }
      return;
    }
    if (m.type === "assistant" && m.message && Array.isArray(m.message.content)) {
      for (const b of m.message.content) {
        if (!b || typeof b !== "object") continue;
        if (b.type === "tool_use") emit({ kind: "tool", text: summariseTool(b.name, b.input) });
        else if (b.type === "text" && !sawPartial) { text(b.text); breakBefore = true; }
      }
      return;
    }
    if (m.type === "result") {
      setSession(m.session_id);
      final = {
        ok: m.is_error !== true && (m.subtype === undefined || m.subtype === "success"),
        subtype: typeof m.subtype === "string" ? m.subtype : "",
        text: typeof m.result === "string" ? m.result : "",
        cost: Number.isFinite(m.total_cost_usd) && m.total_cost_usd >= 0 && m.total_cost_usd < 1000 ? m.total_cost_usd : null,
      };
      // No streamed text at all (a very short reply): use the final text.
      if (!emittedText && final.ok && final.text) text(final.text);
    }
  }

  return {
    feed(chunk) {
      buf += typeof chunk === "string" ? chunk : chunk.toString("utf8");
      let i;
      while ((i = buf.indexOf("\n")) >= 0) { line(buf.slice(0, i)); buf = buf.slice(i + 1); }
      if (buf.length > 1024 * 1024) buf = "";     // a runaway line is dropped, not buffered forever
    },
    end() { if (buf) { line(buf); buf = ""; } },
    get final() { return final; },
    get sessionId() { return sessionId; },
  };
}
