// The folders Claude works in.
//
//   read mode: <reposDir>/<repo> -- one clone of each repository, kept at origin/main
//              (fetched at most every few minutes, before a job).
//   edit mode: <editDir>/<conversation>/<repo> -- a git worktree per repository on the branch
//              claude/chat-<conversation>, created on first use and kept for the conversation.
//              Claude can change files and push that branch, nothing else (see policy.js, the
//              system-wide pre-push hook, and branch protection on main).
//
// Git is called through `git(args, {cwd})` so tests can fake it. A failed fetch is not fatal:
// the job runs on what is already there.

import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";

const CONV = /^cv_[a-z0-9]{8}$/;

export function realGit(args, { cwd, timeoutMs = 120000 } = {}) {
  return new Promise((resolve) => {
    execFile("git", args, { cwd, timeout: timeoutMs, env: { ...process.env, GIT_TERMINAL_PROMPT: "0" }, maxBuffer: 4 * 1024 * 1024 }, (err, stdout, stderr) => {
      resolve({ code: err ? (typeof err.code === "number" ? err.code : 1) : 0, stdout: String(stdout || ""), stderr: String(stderr || "") });
    });
  });
}

export function createWorkspace({ cfg, git = realGit, fsImpl = fs, now = Date.now, log = () => {} }) {
  let refreshedAt = 0;

  async function refresh() {
    if (cfg.refreshEveryMs > 0 && now() - refreshedAt < cfg.refreshEveryMs) return;
    refreshedAt = now();
    fsImpl.mkdirSync(cfg.reposDir, { recursive: true });
    for (const repo of cfg.repos) {
      const dir = path.join(cfg.reposDir, repo);
      if (!fsImpl.existsSync(path.join(dir, ".git"))) {
        const r = await git(["clone", "--quiet", `https://github.com/${cfg.owner}/${repo}.git`, dir]);
        if (r.code !== 0) log(`could not clone ${repo}`);
        continue;
      }
      const f = await git(["fetch", "--quiet", "--prune", "origin"], { cwd: dir });
      if (f.code !== 0) { log(`could not fetch ${repo}`); continue; }
      const c = await git(["checkout", "--quiet", "--force", "--detach", "origin/main"], { cwd: dir });
      if (c.code !== 0) log(`could not update ${repo}`);
    }
  }

  // -> the directory Claude runs in for this job.
  async function prepare(job) {
    // A guest's runner has no repositories: Claude reads the one folder the person chose (read-only).
    if (cfg.profile === "guest") {
      try { fsImpl.mkdirSync(cfg.guestDir, { recursive: true }); } catch (e) { /* a read-only mount already exists */ }
      return cfg.guestDir;
    }
    if (job.mode !== "edit") {
      await refresh();
      return cfg.reposDir;
    }
    if (!CONV.test(job.conv)) throw new Error("bad conversation id");
    await refresh();
    const convDir = path.join(cfg.editDir, job.conv);
    const branch = `claude/chat-${job.conv.slice(3)}`;
    fsImpl.mkdirSync(convDir, { recursive: true });
    for (const repo of cfg.repos) {
      const target = path.join(convDir, repo);
      if (fsImpl.existsSync(target)) continue;
      const main = path.join(cfg.reposDir, repo);
      if (!fsImpl.existsSync(path.join(main, ".git"))) continue;          // not cloned: skip it, the rest still work
      const r = await git(["worktree", "add", "--quiet", "-B", branch, target, "origin/main"], { cwd: main });
      if (r.code !== 0) log(`could not make a worktree for ${repo}`);
    }
    return convDir;
  }

  return { refresh, prepare };
}
